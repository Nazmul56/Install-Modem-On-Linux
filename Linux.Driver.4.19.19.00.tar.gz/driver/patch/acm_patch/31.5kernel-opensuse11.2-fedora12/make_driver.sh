#!/bin/bash

make clean
make modules
make install
